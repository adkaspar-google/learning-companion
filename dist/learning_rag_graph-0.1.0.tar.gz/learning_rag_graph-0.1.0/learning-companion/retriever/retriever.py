# Load Articles (webpages) to documents
# Chunks Documents
# Embed Documents
# Store in ChromaDB Vector Store (in memory)


