









SECRET_KEY = os.environ.get("LANGCHAIN_TRACING_V2")

print(SECRET_KEY)